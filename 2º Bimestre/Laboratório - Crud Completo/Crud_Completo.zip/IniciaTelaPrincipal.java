
public class IniciaTelaPrincipal {

	public static void main(String[] args) {
		Tabela tb = new Tabela();
		TelaPrincipal ts = new TelaPrincipal();
	}

}
